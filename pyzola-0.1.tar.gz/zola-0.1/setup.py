from setuptools import setup,find_packages


setup(
	version='0.1',
	name='zola',
	author='ALI AL-IRAQI',
	description='A powerful encryption libraries in Python created by the ali al-iraqi',
	packages=find_packages(),
	

)




