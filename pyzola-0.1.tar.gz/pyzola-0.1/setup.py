from setuptools import setup,find_packages


setup(
	version='0.1',
	name='pyzola',
	author='ALI KAZM',
	description='A powerful encryption libraries in Python created by ali kazm',
	packages=find_packages(),
	

)




